/**
 * ModelRouter — Aegis Core selects providers through this layer.
 * Default is always free Workers AI (GLM). Paid providers require explicit allow + key.
 */

import { PROVIDER_IDS, createProviders, ModelError } from "./providers.js";

export class ModelRouter {
  constructor(env, providers = null) {
    this.env = env;
    this.providers = providers || createProviders(env);
    this.defaultProvider = PROVIDER_IDS.WORKERS_AI;
    // Simple in-memory daily usage counter for this isolate (best-effort; not durable across isolates)
    this._usage = { calls: 0, paidCalls: 0 };
  }

  listProviders() {
    return Object.values(this.providers).map((p) => ({
      id: p.id,
      name: p.name,
      available: p.isAvailable(),
      requiresKey: p.requiresKey,
      isPaid: p.isPaid,
    }));
  }

  /**
   * Resolve which provider to use.
   * policy: { prefer, allowPaid, purpose }
   */
  resolveProvider(policy = {}) {
    const prefer = policy.prefer || this.defaultProvider;
    const allowPaid = policy.allowPaid === true && this.env.ALLOW_PAID_MODELS === "true";

    if (prefer === PROVIDER_IDS.WORKERS_AI || !allowPaid) {
      const p = this.providers[PROVIDER_IDS.WORKERS_AI];
      if (!p?.isAvailable()) {
        throw new ModelError("Default Workers AI provider is not available.", "NO_DEFAULT");
      }
      return p;
    }

    const candidate = this.providers[prefer];
    if (!candidate) {
      throw new ModelError(`Unknown provider: ${prefer}`, "UNKNOWN_PROVIDER");
    }
    if (!candidate.isAvailable()) {
      // Fallback to free provider instead of failing hard when paid is requested but unavailable
      const fallback = this.providers[PROVIDER_IDS.WORKERS_AI];
      if (fallback?.isAvailable()) return fallback;
      throw new ModelError(
        `Provider ${prefer} is not available (missing key or paid models disabled).`,
        "PROVIDER_UNAVAILABLE"
      );
    }
    return candidate;
  }

  /**
   * Chat through the selected provider. Core decides policy.
   */
  async chat(options = {}) {
    const {
      messages,
      system,
      maxTokens,
      temperature,
      policy = {},
      signal,
    } = options;

    const provider = this.resolveProvider(policy);
    this._usage.calls += 1;
    if (provider.isPaid) this._usage.paidCalls += 1;

    // Soft daily budget (env var, best-effort)
    const maxPaid = Number(this.env.MAX_PAID_CALLS_PER_DAY || 0);
    if (provider.isPaid && maxPaid > 0 && this._usage.paidCalls > maxPaid) {
      throw new ModelError(
        `Paid call budget exceeded (MAX_PAID_CALLS_PER_DAY=${maxPaid}).`,
        "BUDGET_EXCEEDED"
      );
    }

    return provider.chat({
      messages,
      system,
      maxTokens,
      temperature,
      signal,
    });
  }

  getUsage() {
    return { ...this._usage };
  }
}
