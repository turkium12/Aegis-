/**
 * Model provider interface and concrete providers.
 * Workers AI (GLM) is always available when the AI binding exists.
 * DeepSeek and Grok require API keys + explicit allow flags; otherwise they refuse.
 */

export const PROVIDER_IDS = {
  WORKERS_AI: "workers-ai",
  DEEPSEEK: "deepseek",
  GROK: "grok",
};

export class ModelError extends Error {
  constructor(message, code = "MODEL_ERROR") {
    super(message);
    this.name = "ModelError";
    this.code = code;
  }
}

/**
 * Normalize heterogeneous provider responses to plain text.
 */
export function extractText(result) {
  if (typeof result === "string") return result.trim();
  if (typeof result?.response === "string") return result.response.trim();
  const content = result?.choices?.[0]?.message?.content;
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    return content.map((p) => (typeof p === "string" ? p : p?.text || "")).join("").trim();
  }
  if (typeof result?.text === "string") return result.text.trim();
  return "";
}

/**
 * Workers AI provider (GLM-4.7-Flash default). Uses env.AI binding.
 */
export class WorkersAIProvider {
  constructor(env, options = {}) {
    this.env = env;
    this.modelId = options.modelId || env.MODEL_ID || "@cf/zai-org/glm-4.7-flash";
    this.id = PROVIDER_IDS.WORKERS_AI;
    this.name = "Workers AI (GLM)";
    this.requiresKey = false;
    this.isPaid = false;
  }

  isAvailable() {
    return Boolean(this.env?.AI);
  }

  async chat({ messages, system, maxTokens = 700, temperature = 0.55, signal } = {}) {
    if (!this.isAvailable()) {
      throw new ModelError("Workers AI binding (AI) is not configured.", "NO_BINDING");
    }
    const payload = {
      messages: system
        ? [{ role: "system", content: system }, ...messages]
        : messages,
      max_tokens: maxTokens,
      temperature,
    };
    // Workers AI does not accept AbortSignal directly in all runtimes; we still respect timeout via caller.
    const result = await this.env.AI.run(this.modelId, payload);
    const text = extractText(result);
    if (!text) throw new ModelError("Model returned an empty response.", "EMPTY");
    return {
      text,
      model: this.modelId,
      provider: this.id,
      usage: result?.usage || null,
    };
  }
}

/**
 * DeepSeek provider. Real API shape (chat completions). Refuses if key or allow flag missing.
 * Does not invent successful calls.
 */
export class DeepSeekProvider {
  constructor(env, options = {}) {
    this.env = env;
    this.apiKey = env.DEEPSEEK_API_KEY || "";
    this.baseUrl = options.baseUrl || "https://api.deepseek.com";
    this.modelId = options.modelId || env.DEEPSEEK_MODEL || "deepseek-chat";
    this.id = PROVIDER_IDS.DEEPSEEK;
    this.name = "DeepSeek";
    this.requiresKey = true;
    this.isPaid = true;
  }

  isAvailable() {
    return Boolean(this.apiKey) && this.env.ALLOW_PAID_MODELS === "true";
  }

  async chat({ messages, system, maxTokens = 1024, temperature = 0.4, signal } = {}) {
    if (!this.apiKey) {
      throw new ModelError(
        "DeepSeek API key not configured. Set DEEPSEEK_API_KEY secret and ALLOW_PAID_MODELS=true.",
        "NO_KEY"
      );
    }
    if (this.env.ALLOW_PAID_MODELS !== "true") {
      throw new ModelError(
        "Paid models are disabled. Set ALLOW_PAID_MODELS=true and define a budget before use.",
        "PAID_DISABLED"
      );
    }
    const body = {
      model: this.modelId,
      messages: system
        ? [{ role: "system", content: system }, ...messages]
        : messages,
      max_tokens: maxTokens,
      temperature,
      stream: false,
    };
    const controller = signal ? undefined : new AbortController();
    const timeout = setTimeout(() => controller?.abort(), 25000);
    try {
      const res = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: signal || controller.signal,
      });
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new ModelError(
          `DeepSeek HTTP ${res.status}: ${errText.slice(0, 200) || res.statusText}`,
          "HTTP_ERROR"
        );
      }
      const data = await res.json();
      const text = extractText(data);
      if (!text) throw new ModelError("DeepSeek returned empty content.", "EMPTY");
      return {
        text,
        model: this.modelId,
        provider: this.id,
        usage: data.usage || null,
      };
    } finally {
      clearTimeout(timeout);
    }
  }
}

/**
 * xAI Grok provider. Real API shape. Refuses without key + allow flag.
 */
export class GrokProvider {
  constructor(env, options = {}) {
    this.env = env;
    this.apiKey = env.XAI_API_KEY || env.GROK_API_KEY || "";
    this.baseUrl = options.baseUrl || "https://api.x.ai";
    this.modelId = options.modelId || env.GROK_MODEL || "grok-2-latest";
    this.id = PROVIDER_IDS.GROK;
    this.name = "xAI Grok";
    this.requiresKey = true;
    this.isPaid = true;
  }

  isAvailable() {
    return Boolean(this.apiKey) && this.env.ALLOW_PAID_MODELS === "true";
  }

  async chat({ messages, system, maxTokens = 1024, temperature = 0.4, signal } = {}) {
    if (!this.apiKey) {
      throw new ModelError(
        "Grok/xAI API key not configured. Set XAI_API_KEY secret and ALLOW_PAID_MODELS=true.",
        "NO_KEY"
      );
    }
    if (this.env.ALLOW_PAID_MODELS !== "true") {
      throw new ModelError(
        "Paid models are disabled. Set ALLOW_PAID_MODELS=true and define a budget before use.",
        "PAID_DISABLED"
      );
    }
    const body = {
      model: this.modelId,
      messages: system
        ? [{ role: "system", content: system }, ...messages]
        : messages,
      max_tokens: maxTokens,
      temperature,
      stream: false,
    };
    const controller = signal ? undefined : new AbortController();
    const timeout = setTimeout(() => controller?.abort(), 25000);
    try {
      const res = await fetch(`${this.baseUrl}/v1/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: signal || controller.signal,
      });
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new ModelError(
          `Grok HTTP ${res.status}: ${errText.slice(0, 200) || res.statusText}`,
          "HTTP_ERROR"
        );
      }
      const data = await res.json();
      const text = extractText(data);
      if (!text) throw new ModelError("Grok returned empty content.", "EMPTY");
      return {
        text,
        model: this.modelId,
        provider: this.id,
        usage: data.usage || null,
      };
    } finally {
      clearTimeout(timeout);
    }
  }
}

/**
 * Create the set of providers from env. Never invents availability.
 */
export function createProviders(env) {
  return {
    [PROVIDER_IDS.WORKERS_AI]: new WorkersAIProvider(env),
    [PROVIDER_IDS.DEEPSEEK]: new DeepSeekProvider(env),
    [PROVIDER_IDS.GROK]: new GrokProvider(env),
  };
}
