/**
 * Memory system for Aegis.
 * - Persistent backend: Cloudflare KV (when binding present)
 * - Test / fallback: in-memory Map
 * Records include source, timestamp, confidence, user isolation.
 */

const MAX_VALUE_LENGTH = 4000;
const MAX_KEY_LENGTH = 128;
const DEFAULT_TTL_SECONDS = 60 * 60 * 24 * 30; // 30 days

export class MemoryError extends Error {
  constructor(message, code = "MEMORY_ERROR") {
    super(message);
    this.name = "MemoryError";
    this.code = code;
  }
}

function sanitizeKey(key) {
  if (typeof key !== "string") throw new MemoryError("Key must be a string", "INVALID_KEY");
  const k = key.trim().slice(0, MAX_KEY_LENGTH);
  if (!k || !/^[a-zA-Z0-9:_\-./]+$/.test(k)) {
    throw new MemoryError("Key contains invalid characters", "INVALID_KEY");
  }
  return k;
}

function userPrefix(userId) {
  const id = String(userId || "anonymous").replace(/[^a-zA-Z0-9_\-]/g, "").slice(0, 64) || "anonymous";
  return `u:${id}:`;
}

/**
 * In-memory backend (for tests and when KV is absent).
 */
export class InMemoryBackend {
  constructor() {
    this.map = new Map();
  }
  async get(key) {
    const entry = this.map.get(key);
    if (!entry) return null;
    if (entry.expiresAt && Date.now() > entry.expiresAt) {
      this.map.delete(key);
      return null;
    }
    return entry.value;
  }
  async put(key, value, { expirationTtl } = {}) {
    const expiresAt = expirationTtl ? Date.now() + expirationTtl * 1000 : null;
    this.map.set(key, { value, expiresAt });
  }
  async delete(key) {
    this.map.delete(key);
  }
  async list({ prefix = "" } = {}) {
    const keys = [];
    for (const k of this.map.keys()) {
      if (k.startsWith(prefix)) keys.push({ name: k });
    }
    return { keys };
  }
}

/**
 * KV backend wrapper.
 */
export class KVBackend {
  constructor(kv) {
    this.kv = kv;
  }
  async get(key) {
    return this.kv.get(key);
  }
  async put(key, value, opts = {}) {
    const options = {};
    if (opts.expirationTtl) options.expirationTtl = opts.expirationTtl;
    await this.kv.put(key, value, options);
  }
  async delete(key) {
    await this.kv.delete(key);
  }
  async list({ prefix = "" } = {}) {
    return this.kv.list({ prefix });
  }
}

/**
 * High-level memory API used by Aegis Core and tools.
 */
export class MemoryStore {
  constructor(backend, options = {}) {
    this.backend = backend;
    this.defaultTtl = options.defaultTtl ?? DEFAULT_TTL_SECONDS;
    this.maxEntriesPerUser = options.maxEntriesPerUser ?? 100;
  }

  _fullKey(userId, key) {
    return userPrefix(userId) + sanitizeKey(key);
  }

  /**
   * Save a memory item.
   * meta: { source, confidence (0-1), tags? }
   */
  async save(userId, key, content, meta = {}) {
    if (typeof content !== "string" || !content.trim()) {
      throw new MemoryError("Content must be a non-empty string", "INVALID_CONTENT");
    }
    if (content.length > MAX_VALUE_LENGTH) {
      throw new MemoryError(`Content exceeds ${MAX_VALUE_LENGTH} characters`, "TOO_LONG");
    }
    const record = {
      content: content.trim(),
      source: String(meta.source || "user").slice(0, 64),
      confidence: Math.min(1, Math.max(0, Number(meta.confidence ?? 0.5))),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      tags: Array.isArray(meta.tags) ? meta.tags.slice(0, 8).map(String) : [],
    };
    const fullKey = this._fullKey(userId, key);
    await this.backend.put(fullKey, JSON.stringify(record), {
      expirationTtl: this.defaultTtl,
    });
    return { key: sanitizeKey(key), ...record };
  }

  async get(userId, key) {
    const raw = await this.backend.get(this._fullKey(userId, key));
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  async delete(userId, key) {
    await this.backend.delete(this._fullKey(userId, key));
    return true;
  }

  /**
   * List keys for a user (metadata only). Limited.
   */
  async list(userId, { limit = 50 } = {}) {
    const prefix = userPrefix(userId);
    const result = await this.backend.list({ prefix });
    const keys = (result.keys || []).slice(0, limit).map((k) => ({
      key: k.name.slice(prefix.length),
      name: k.name,
    }));
    return keys;
  }

  /**
   * Simple text search over listed items (fetch + filter). Suitable for small stores.
   */
  async search(userId, query, { limit = 10 } = {}) {
    const q = String(query || "").toLowerCase().trim();
    if (!q) return [];
    const listed = await this.list(userId, { limit: 50 });
    const hits = [];
    for (const item of listed) {
      const rec = await this.get(userId, item.key);
      if (!rec) continue;
      const hay = `${item.key} ${rec.content} ${(rec.tags || []).join(" ")}`.toLowerCase();
      if (hay.includes(q)) {
        hits.push({ key: item.key, ...rec });
        if (hits.length >= limit) break;
      }
    }
    return hits;
  }
}

/**
 * Factory: prefer KV binding, else in-memory.
 */
export function createMemoryStore(env) {
  if (env?.AEGIS_MEMORY) {
    return new MemoryStore(new KVBackend(env.AEGIS_MEMORY));
  }
  return new MemoryStore(new InMemoryBackend());
}
