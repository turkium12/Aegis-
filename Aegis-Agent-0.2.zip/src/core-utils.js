/**
 * Pure utilities extracted/expanded from Aegis 0.1 core.
 * No I/O. Safe for unit tests.
 */

export const DEFAULT_MODEL = "@cf/zai-org/glm-4.7-flash";

export const SYSTEM_PROMPT = `You are Aegis, an independent general-purpose AI agent (version 0.2).
Respond in the user's language; use clear Turkish when the user writes Turkish.
Be accurate. Distinguish verified facts from uncertainty.
Never claim to have used tools, browsed the web, changed files, or completed external actions unless the application actually did so in this request.
You have no unrestricted web browsing or shell access in this version.
For current real-world facts that require live verification, say that live verification is unavailable unless a tool result is provided in the context.
Keep answers structured and concise.
If the user asks for multi-step work, outline a short plan and execute only safe steps available in the system.`;

export function validateMessages(input) {
  if (!Array.isArray(input)) throw new Error("messages must be an array");
  const allowed = new Set(["user", "assistant"]);
  const clean = input.slice(-12).map((m) => {
    if (!m || !allowed.has(m.role) || typeof m.content !== "string") {
      throw new Error("invalid message");
    }
    const content = m.content.trim();
    if (!content || content.length > 5000) throw new Error("message length must be 1..5000");
    return { role: m.role, content };
  });
  if (!clean.length || clean[clean.length - 1].role !== "user") {
    throw new Error("last message must be from user");
  }
  return clean;
}

// A small arithmetic parser. No eval(), Function(), or dynamic code execution.
export function calculate(expression) {
  const s = expression.replace(/\s+/g, "");
  if (!s || s.length > 120 || !/^[0-9.+\-*/%()]+$/.test(s)) {
    throw new Error("Only arithmetic expressions are supported");
  }
  let i = 0;
  function expr() {
    let value = term();
    while (s[i] === "+" || s[i] === "-") {
      const op = s[i++];
      const rhs = term();
      value = op === "+" ? value + rhs : value - rhs;
    }
    return value;
  }
  function term() {
    let value = factor();
    while (s[i] === "*" || s[i] === "/" || s[i] === "%") {
      const op = s[i++];
      const rhs = factor();
      if ((op === "/" || op === "%") && rhs === 0) throw new Error("Division by zero");
      value = op === "*" ? value * rhs : op === "/" ? value / rhs : value % rhs;
    }
    return value;
  }
  function factor() {
    if (s[i] === "+") {
      i++;
      return factor();
    }
    if (s[i] === "-") {
      i++;
      return -factor();
    }
    if (s[i] === "(") {
      i++;
      const value = expr();
      if (s[i++] !== ")") throw new Error("Unmatched parenthesis");
      return value;
    }
    const start = i;
    while (/[0-9.]/.test(s[i] || "")) i++;
    if (start === i) throw new Error("Invalid expression");
    const token = s.slice(start, i);
    if ((token.match(/\./g) || []).length > 1) throw new Error("Invalid number");
    const value = Number(token);
    if (!Number.isFinite(value)) throw new Error("Invalid number");
    return value;
  }
  const result = expr();
  if (i !== s.length || !Number.isFinite(result)) throw new Error("Invalid expression");
  return Number(result.toPrecision(12));
}

/** Legacy builtin helper kept for compatibility */
export function runBuiltinCommand(text, now = new Date()) {
  if (text.startsWith("/help")) {
    return (
      "Aegis 0.2 komutları:\n" +
      "/calc 12*(5+3) — güvenli matematik\n" +
      "/time — UTC tarih ve saat\n" +
      "/help — komut listesi\n" +
      "/memory save|get|list|search|delete — kullanıcı hafızası\n" +
      "Diğer mesajlar Aegis Core üzerinden işlenir."
    );
  }
  if (text.startsWith("/time")) {
    return `Şu an UTC: ${now.toISOString()}`;
  }
  if (text.startsWith("/calc")) {
    const expression = text.slice(5).trim();
    if (!expression) return "Kullanım: /calc 12*(5+3)";
    return `Sonuç: ${calculate(expression)}`;
  }
  return null;
}

export function extractAssistantText(result) {
  if (typeof result === "string") return result;
  if (typeof result?.response === "string") return result.response;
  const content = result?.choices?.[0]?.message?.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content.map((part) => part?.text || "").join("");
  }
  return "";
}

/**
 * Very light heuristic: detect common capability-hallucination phrases.
 */
export function detectCapabilityClaims(text) {
  const t = String(text || "").toLowerCase();
  const patterns = [
    /i (have |just )?(browsed|searched|opened|visited) the (web|internet|page)/i,
    /i (ran|executed|wrote|modified) (the )?(code|file|script|command)/i,
    /i (have )?(access to|used) (the )?(shell|terminal|filesystem)/i,
    /(şimdi|az önce) (web|internet|sayfa).*(taradım|baktım|açtım)/i,
    /(kodu|dosyayı|komutu).*(çalıştırdım|yazdım|değiştirdim)/i,
  ];
  return patterns.some((re) => re.test(t));
}
