export const PAGE = `<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#111827"><title>Aegis Agent 0.2</title>
<style>
:root{color-scheme:dark;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#0b1020;color:#e5e7eb}
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:flex;justify-content:center}
main{width:min(900px,100%);padding:20px;display:flex;flex-direction:column;min-height:100vh}
header{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #293247;padding-bottom:12px;margin-bottom:12px}
h1{font-size:1.25rem;margin:0}
.muted{color:#9ca3af;font-size:.85rem}
.msg{padding:10px 12px;border-radius:10px;margin:8px 0;white-space:pre-wrap;line-height:1.45}
.msg.user{background:#1e293b;border:1px solid #334155}
.msg.assistant{background:#111827;border:1px solid #1f2937}
#messages{flex:1;overflow:auto;padding:8px 0;max-height:55vh}
form{display:flex;gap:8px;margin-top:12px}
textarea{flex:1;min-height:64px;resize:vertical;background:#0f172a;border:1px solid #334155;border-radius:8px;color:inherit;padding:10px}
button{background:#2563eb;color:#fff;border:0;border-radius:8px;padding:10px 16px;cursor:pointer;font-weight:600}
button.secondary{background:#334155}
button:disabled{opacity:.5;cursor:not-allowed}
input#token{width:100%;background:#0f172a;border:1px solid #334155;border-radius:8px;color:inherit;padding:8px;margin-top:4px}
label{display:block;margin-top:8px}
.tools{margin-top:8px}
.meta{font-size:.75rem;color:#6b7280;margin-top:4px}
</style>
</head>
<body>
<main>
<header>
  <div><h1>Aegis</h1><div class="muted">Independent AI Agent · 0.2.0</div></div>
  <button class="secondary" id="clear" type="button">Temizle</button>
</header>
<section aria-label="Access">
  <label class="muted" for="token">Erişim anahtarı (Cloudflare secret)</label>
  <input id="token" type="password" autocomplete="off" placeholder="Aegis erişim anahtarını gir">
  <div class="muted">Anahtar yalnızca bu sekmenin oturumunda tutulur. Sohbet geçmişi bu tarayıcıda saklanır. Sunucu hafızası kullanıcıya göre ayrılır (KV).</div>
</section>
<div id="messages" aria-live="polite"></div>
<div class="muted">Komutlar: /help · /time · /calc 12*(5+3) · /memory save|get|list|search|delete</div>
<form id="form">
  <textarea id="prompt" placeholder="Aegis'e bir görev ver..." required></textarea>
  <button id="send" type="submit">Gönder</button>
</form>
<div class="tools"><span class="muted" id="status">Hazır</span></div>
</main>
<script>
const $=s=>document.querySelector(s);
const KEY="aegis.messages.v2";
let messages=[];
try{messages=JSON.parse(localStorage.getItem(KEY)||"[]")}catch{messages=[]}
$("#token").value=sessionStorage.getItem("aegis.token")||"";
function render(){
  const root=$("#messages");
  root.replaceChildren();
  for(const m of messages){
    const d=document.createElement("div");
    d.className="msg "+m.role;
    d.textContent=m.content;
    root.append(d);
    if(m.meta){
      const meta=document.createElement("div");
      meta.className="meta";
      meta.textContent=m.meta;
      root.append(meta);
    }
  }
  root.scrollTop=root.scrollHeight;
}
function save(){
  localStorage.setItem(KEY,JSON.stringify(messages.slice(-40)));
  render();
}
render();
$("#token").addEventListener("change",()=>sessionStorage.setItem("aegis.token",$("#token").value.trim()));
$("#clear").onclick=()=>{messages=[];save()};
$("#form").addEventListener("submit",async e=>{
  e.preventDefault();
  const text=$("#prompt").value.trim();
  if(!text)return;
  const token=$("#token").value.trim();
  if(!token){$("#status").textContent="Önce erişim anahtarını gir.";return}
  sessionStorage.setItem("aegis.token",token);
  $("#prompt").value="";
  messages.push({role:"user",content:text});
  save();
  $("#send").disabled=true;
  $("#status").textContent="Yanıt hazırlanıyor...";
  try{
    const r=await fetch("/api/chat",{
      method:"POST",
      headers:{"content-type":"application/json","authorization":"Bearer "+token},
      body:JSON.stringify({messages:messages.slice(-12)})
    });
    const data=await r.json();
    if(!r.ok)throw new Error(data.error||"İstek başarısız");
    const meta=[data.model,data.provider].filter(Boolean).join(" · ");
    messages.push({role:"assistant",content:data.reply,meta:meta||undefined});
    save();
    $("#status").textContent=meta?("Model: "+meta):"Tamam";
  }catch(err){
    messages.push({role:"assistant",content:"Hata: "+err.message});
    save();
    $("#status").textContent="İstek tamamlanamadı";
  }finally{
    $("#send").disabled=false;
    $("#prompt").focus();
  }
});
</script>
</body>
</html>`;
