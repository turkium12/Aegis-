/**
 * Security and cost controls for Aegis 0.2.
 * Auth, rate limiting (best-effort via KV or memory), input hardening.
 */

export class SecurityError extends Error {
  constructor(message, code = "SECURITY", status = 403) {
    super(message);
    this.name = "SecurityError";
    this.code = code;
    this.status = status;
  }
}

export function isAuthorized(request, env) {
  const expected = env.AEGIS_ACCESS_TOKEN;
  if (!expected) return false;
  const supplied = request.headers.get("authorization") || "";
  return supplied === `Bearer ${expected}`;
}

/**
 * Derive a stable user id from the access token (hash-like, not reversible secret).
 * In 0.2 we use a simple non-crypto fingerprint so memory is isolated per token
 * without storing the raw token as key.
 */
export function userIdFromToken(token) {
  if (!token || typeof token !== "string") return "anonymous";
  let h = 0;
  for (let i = 0; i < token.length; i++) {
    h = (Math.imul(31, h) + token.charCodeAt(i)) | 0;
  }
  return `t${(h >>> 0).toString(16)}`;
}

/**
 * Simple sliding window rate limiter.
 * Uses KV when available; otherwise in-memory Map (per isolate).
 */
export class RateLimiter {
  constructor(backend, options = {}) {
    this.backend = backend; // { get, put } or null
    this.windowMs = options.windowMs ?? 60_000;
    this.maxRequests = options.maxRequests ?? 30;
    this._mem = new Map();
  }

  async check(key) {
    const now = Date.now();
    const bucketKey = `rl:${key}`;

    let state = null;
    if (this.backend) {
      const raw = await this.backend.get(bucketKey);
      if (raw) {
        try {
          state = JSON.parse(raw);
        } catch {
          state = null;
        }
      }
    } else {
      state = this._mem.get(bucketKey) || null;
    }

    if (!state || now - state.start > this.windowMs) {
      state = { start: now, count: 0 };
    }
    state.count += 1;

    if (this.backend) {
      await this.backend.put(bucketKey, JSON.stringify(state), {
        expirationTtl: Math.ceil(this.windowMs / 1000) + 5,
      });
    } else {
      this._mem.set(bucketKey, state);
    }

    if (state.count > this.maxRequests) {
      throw new SecurityError(
        `Rate limit exceeded (${this.maxRequests} requests per ${Math.round(this.windowMs / 1000)}s).`,
        "RATE_LIMIT",
        429
      );
    }
    return { remaining: Math.max(0, this.maxRequests - state.count) };
  }
}

/**
 * Basic prompt-injection / override heuristics on user text.
 * Does not block; returns warnings for Core / Verification to use.
 */
export function scanUserInput(text) {
  const warnings = [];
  const t = String(text || "");
  const lower = t.toLowerCase();
  if (
    /ignore (all )?(previous|prior|above) (instructions|prompts)/i.test(t) ||
    /system prompt('u|u)? (yoksay|ignore)/i.test(lower) ||
    /you are now (dan|a different|unrestricted)/i.test(t)
  ) {
    warnings.push("possible_prompt_injection");
  }
  if (t.length > 4000) warnings.push("long_input");
  return warnings;
}
