/**
 * Agent Engine — simple task analysis, planning, and safe step execution.
 * 0.2 scope: single-turn or short plan with only registered safe tools.
 * No autonomous external side effects without explicit tool + risk policy.
 */

import { parseSlashCommand } from "../tools/registry.js";

/**
 * Classify user intent roughly.
 */
export function analyzeTask(userText) {
  const t = String(userText || "").trim();
  const slash = parseSlashCommand(t);
  if (slash) {
    return {
      type: "tool",
      tool: slash.tool,
      args: slash.args,
      legacy: slash.legacy || null,
    };
  }

  // Heuristic multi-step signals
  const lower = t.toLowerCase();
  const multi =
    /\b(adım adım|step by step|plan|planla|önce|sonra|then|after that)\b/i.test(t) ||
    (lower.includes("ve") && lower.length > 80);

  if (/\b(hatırla|kaydet|hafıza|remember|save this)\b/i.test(t)) {
    return { type: "memory_intent", text: t };
  }

  return {
    type: multi ? "plan" : "chat",
    text: t,
  };
}

/**
 * Build a short plan description (for logging / UI). Execution still goes through tools or model.
 */
export function buildPlan(analysis, availableTools = []) {
  if (analysis.type === "tool") {
    return {
      steps: [{ action: "run_tool", tool: analysis.tool, args: analysis.args }],
      reason: "Direct tool command",
    };
  }
  if (analysis.type === "memory_intent") {
    return {
      steps: [
        { action: "clarify_or_model", note: "Memory-related request; model may suggest /memory commands" },
      ],
      reason: "Memory intent",
    };
  }
  if (analysis.type === "plan") {
    return {
      steps: [
        { action: "model_plan", note: "Ask model for a short plan using only safe tools" },
        { action: "model_answer", note: "Produce final answer" },
      ],
      reason: "Multi-step language detected",
    };
  }
  return {
    steps: [{ action: "model_answer", note: "Direct chat" }],
    reason: "Simple chat",
  };
}

/**
 * Execute a single safe tool step.
 */
export async function executeToolStep(registry, ctx, toolName, args) {
  const tool = registry.get(toolName);
  if (!tool) {
    return { ok: false, error: `Tool not found: ${toolName}` };
  }
  // In 0.2, confirm-risk tools still run when invoked via explicit slash command
  // (user already typed the command). Future versions can require a second confirmation.
  return registry.run(toolName, ctx, args);
}
