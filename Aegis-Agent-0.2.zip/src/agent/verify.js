/**
 * Verification Engine — lightweight checks on model output.
 * Does not claim external truth; flags risk patterns and capability claims.
 */

import { detectCapabilityClaims } from "../core-utils.js";

/**
 * Verify a model reply before returning to the user.
 * Returns { text, flags[], adjusted }
 */
export function verifyReply(text, context = {}) {
  const flags = [];
  let adjusted = String(text || "");

  if (!adjusted.trim()) {
    flags.push("empty_reply");
    return { text: adjusted, flags, adjusted: false };
  }

  if (detectCapabilityClaims(adjusted)) {
    flags.push("capability_claim");
    // Soft disclaimer rather than rewriting the whole answer
    adjusted +=
      "\n\n[Aegis doğrulama] Bu yanıt, sistemin gerçekten yapmadığı eylemleri (web tarama, dosya değiştirme, kabuk komutu vb.) ima ediyor olabilir. 0.2 sürümünde yalnızca kayıtlı güvenli araçlar çalışır.";
  }

  // Conflicting multi-model support is prepared but not active until paid models are used
  if (context.otherReplies && Array.isArray(context.otherReplies) && context.otherReplies.length) {
    flags.push("multi_model_present");
    // Do not treat agreement as proof
  }

  if (context.inputWarnings?.includes("possible_prompt_injection")) {
    flags.push("user_injection_warning");
  }

  return {
    text: adjusted,
    flags,
    adjusted: adjusted !== text,
  };
}

/**
 * Compare two model texts for crude contradiction (keyword level). Placeholder for 0.3+.
 */
export function detectConflict(a, b) {
  if (!a || !b) return false;
  // Extremely naive: opposite polarity words — only a hook for future work
  const neg = /\b(not|no|false|yanlış|değil|hayır)\b/i;
  const aNeg = neg.test(a);
  const bNeg = neg.test(b);
  return aNeg !== bNeg && a.length > 40 && b.length > 40;
}
