/**
 * Safe, limited tools for Aegis 0.2.
 * No shell, no network (except model providers), no file system, no code execution.
 * Tools that mutate state (memory write/delete) are marked and can require confirmation.
 */

import { calculate, runBuiltinCommand } from "../core-utils.js";

export class ToolError extends Error {
  constructor(message, code = "TOOL_ERROR") {
    super(message);
    this.name = "ToolError";
    this.code = code;
  }
}

/**
 * Tool definition shape:
 * { name, description, risk: "safe"|"confirm", parameters, execute(ctx, args) }
 */
export function createToolRegistry({ memory, now = () => new Date() } = {}) {
  const tools = new Map();

  function register(tool) {
    tools.set(tool.name, tool);
  }

  register({
    name: "help",
    description: "List available commands and tools",
    risk: "safe",
    parameters: {},
    async execute() {
      return {
        ok: true,
        result:
          "Aegis 0.2 tools:\n" +
          "/help — this list\n" +
          "/time — current UTC time\n" +
          "/calc <expr> — safe arithmetic\n" +
          "/memory save <key> <text> — store a memory (user-scoped)\n" +
          "/memory get <key> — recall a memory\n" +
          "/memory list — list memory keys\n" +
          "/memory search <query> — search memories\n" +
          "/memory delete <key> — delete a memory\n" +
          "Other messages go through Aegis Core (plan → model → verify).",
      };
    },
  });

  register({
    name: "time",
    description: "Return current UTC ISO time",
    risk: "safe",
    parameters: {},
    async execute() {
      return { ok: true, result: `UTC: ${now().toISOString()}` };
    },
  });

  register({
    name: "calc",
    description: "Evaluate a safe arithmetic expression",
    risk: "safe",
    parameters: { expression: "string" },
    async execute(_ctx, args) {
      const expression = String(args.expression || "").trim();
      if (!expression) return { ok: false, error: "Usage: /calc 12*(5+3)" };
      try {
        const value = calculate(expression);
        return { ok: true, result: `Sonuç: ${value}` };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    },
  });

  register({
    name: "memory_save",
    description: "Save a key-value memory for the current user",
    risk: "confirm",
    parameters: { key: "string", content: "string" },
    async execute(ctx, args) {
      if (!memory) return { ok: false, error: "Memory not configured" };
      const key = String(args.key || "").trim();
      const content = String(args.content || "").trim();
      if (!key || !content) return { ok: false, error: "Usage: /memory save <key> <text>" };
      const saved = await memory.save(ctx.userId, key, content, {
        source: "user",
        confidence: 0.8,
      });
      return { ok: true, result: `Kaydedildi: ${saved.key} (${saved.createdAt})` };
    },
  });

  register({
    name: "memory_get",
    description: "Get a memory by key",
    risk: "safe",
    parameters: { key: "string" },
    async execute(ctx, args) {
      if (!memory) return { ok: false, error: "Memory not configured" };
      const key = String(args.key || "").trim();
      if (!key) return { ok: false, error: "Usage: /memory get <key>" };
      const rec = await memory.get(ctx.userId, key);
      if (!rec) return { ok: true, result: `Bulunamadı: ${key}` };
      return {
        ok: true,
        result: `[${key}] ${rec.content}\n(kaynak: ${rec.source}, güven: ${rec.confidence}, ${rec.updatedAt || rec.createdAt})`,
      };
    },
  });

  register({
    name: "memory_list",
    description: "List memory keys for the user",
    risk: "safe",
    parameters: {},
    async execute(ctx) {
      if (!memory) return { ok: false, error: "Memory not configured" };
      const keys = await memory.list(ctx.userId, { limit: 40 });
      if (!keys.length) return { ok: true, result: "Hafızada kayıt yok." };
      return { ok: true, result: "Anahtarlar:\n" + keys.map((k) => `- ${k.key}`).join("\n") };
    },
  });

  register({
    name: "memory_search",
    description: "Search memories by text",
    risk: "safe",
    parameters: { query: "string" },
    async execute(ctx, args) {
      if (!memory) return { ok: false, error: "Memory not configured" };
      const query = String(args.query || "").trim();
      if (!query) return { ok: false, error: "Usage: /memory search <query>" };
      const hits = await memory.search(ctx.userId, query, { limit: 8 });
      if (!hits.length) return { ok: true, result: "Eşleşme yok." };
      return {
        ok: true,
        result: hits
          .map((h) => `- [${h.key}] ${h.content.slice(0, 120)}${h.content.length > 120 ? "…" : ""}`)
          .join("\n"),
      };
    },
  });

  register({
    name: "memory_delete",
    description: "Delete a memory key",
    risk: "confirm",
    parameters: { key: "string" },
    async execute(ctx, args) {
      if (!memory) return { ok: false, error: "Memory not configured" };
      const key = String(args.key || "").trim();
      if (!key) return { ok: false, error: "Usage: /memory delete <key>" };
      await memory.delete(ctx.userId, key);
      return { ok: true, result: `Silindi: ${key}` };
    },
  });

  return {
    get(name) {
      return tools.get(name) || null;
    },
    list() {
      return [...tools.values()].map((t) => ({
        name: t.name,
        description: t.description,
        risk: t.risk,
      }));
    },
    async run(name, ctx, args = {}) {
      const tool = tools.get(name);
      if (!tool) throw new ToolError(`Unknown tool: ${name}`, "UNKNOWN");
      return tool.execute(ctx, args);
    },
  };
}

/**
 * Parse slash commands into tool + args.
 */
export function parseSlashCommand(text) {
  const t = String(text || "").trim();
  if (!t.startsWith("/")) return null;

  if (t.startsWith("/help")) return { tool: "help", args: {} };
  if (t.startsWith("/time")) return { tool: "time", args: {} };
  if (t.startsWith("/calc")) {
    return { tool: "calc", args: { expression: t.slice(5).trim() } };
  }
  if (t.startsWith("/memory")) {
    const rest = t.slice(8).trim();
    const [action, ...parts] = rest.split(/\s+/);
    if (action === "save") {
      const key = parts[0] || "";
      const content = parts.slice(1).join(" ");
      return { tool: "memory_save", args: { key, content } };
    }
    if (action === "get") return { tool: "memory_get", args: { key: parts[0] || "" } };
    if (action === "list") return { tool: "memory_list", args: {} };
    if (action === "search") return { tool: "memory_search", args: { query: parts.join(" ") } };
    if (action === "delete") return { tool: "memory_delete", args: { key: parts[0] || "" } };
    return { tool: "help", args: {} };
  }
  // Legacy compatibility
  const legacy = runBuiltinCommand(t);
  if (legacy !== null) return { tool: "_legacy", args: { text: t }, legacy };
  return null;
}
