/**
 * Cloudflare Worker entry for Aegis 0.2
 */

import { PAGE } from "./ui.js";
import { createCore, DEFAULT_MODEL } from "./core.js";
import { isAuthorized } from "./security/guard.js";

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/") {
      return new Response(PAGE, {
        headers: {
          "content-type": "text/html; charset=utf-8",
          "cache-control": "no-store",
        },
      });
    }

    if (request.method === "GET" && url.pathname === "/api/health") {
      const core = createCore(env);
      return json({
        ok: true,
        service: "Aegis Agent",
        version: "0.2.0",
        model: env.MODEL_ID || DEFAULT_MODEL,
        status: core.status(),
      });
    }

    if (url.pathname !== "/api/chat") {
      return json({ error: "Not found" }, 404);
    }
    if (request.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }
    if (!isAuthorized(request, env)) {
      return json(
        {
          error:
            "Unauthorized. Configure AEGIS_ACCESS_TOKEN and enter it in the app.",
        },
        401
      );
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: "Request body must be valid JSON." }, 400);
    }

    const authHeader = request.headers.get("authorization") || "";
    const token = authHeader.startsWith("Bearer ")
      ? authHeader.slice(7)
      : "";

    try {
      const core = createCore(env);
      const result = await core.handleChat({
        messages: body?.messages,
        authToken: token,
        policy: body?.policy || {},
      });

      if (result.error) {
        return json(
          {
            error: result.reply,
            model: result.model,
            flags: result.flags,
          },
          502
        );
      }

      return json({
        reply: result.reply,
        model: result.model,
        provider: result.provider,
        plan: result.plan,
        flags: result.flags,
      });
    } catch (error) {
      const status = error.status || 500;
      const message =
        error.name === "SecurityError"
          ? error.message
          : error.message && String(error.message).includes("message")
            ? error.message
            : "Request failed.";
      return json(
        { error: message },
        status >= 400 && status < 600 ? status : 500
      );
    }
  },
};
