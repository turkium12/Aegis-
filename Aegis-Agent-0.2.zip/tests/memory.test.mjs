import test from "node:test";
import assert from "node:assert/strict";
import { MemoryStore, InMemoryBackend } from "../src/memory/store.js";

test("memory save get list search delete with user isolation", async () => {
  const store = new MemoryStore(new InMemoryBackend());
  await store.save("userA", "pref", "likes dark mode", { source: "user", confidence: 0.9 });
  await store.save("userB", "pref", "likes light mode", { source: "user", confidence: 0.9 });

  const a = await store.get("userA", "pref");
  const b = await store.get("userB", "pref");
  assert.equal(a.content, "likes dark mode");
  assert.equal(b.content, "likes light mode");

  const listA = await store.list("userA");
  assert.equal(listA.length, 1);
  assert.equal(listA[0].key, "pref");

  const hits = await store.search("userA", "dark");
  assert.equal(hits.length, 1);

  await store.delete("userA", "pref");
  assert.equal(await store.get("userA", "pref"), null);
  assert.ok(await store.get("userB", "pref"));
});

test("memory rejects empty content and bad keys", async () => {
  const store = new MemoryStore(new InMemoryBackend());
  await assert.rejects(() => store.save("u", "k", ""));
  await assert.rejects(() => store.save("u", "bad key!", "x"));
});
