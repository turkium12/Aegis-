import test from "node:test";
import assert from "node:assert/strict";
import { ModelRouter } from "../src/models/router.js";
import { PROVIDER_IDS, ModelError } from "../src/models/providers.js";

test("router defaults to workers-ai and refuses unpaid paid providers", async () => {
  const env = { ALLOW_PAID_MODELS: "false", MODEL_ID: "@cf/zai-org/glm-4.7-flash" };
  // Mock Workers AI provider
  const mockProviders = {
    [PROVIDER_IDS.WORKERS_AI]: {
      id: PROVIDER_IDS.WORKERS_AI,
      name: "Workers AI",
      requiresKey: false,
      isPaid: false,
      isAvailable: () => true,
      chat: async () => ({ text: "ok-glm", model: "glm", provider: PROVIDER_IDS.WORKERS_AI }),
    },
    [PROVIDER_IDS.DEEPSEEK]: {
      id: PROVIDER_IDS.DEEPSEEK,
      name: "DeepSeek",
      requiresKey: true,
      isPaid: true,
      isAvailable: () => false,
      chat: async () => {
        throw new ModelError("no", "NO_KEY");
      },
    },
    [PROVIDER_IDS.GROK]: {
      id: PROVIDER_IDS.GROK,
      name: "Grok",
      requiresKey: true,
      isPaid: true,
      isAvailable: () => false,
      chat: async () => {
        throw new ModelError("no", "NO_KEY");
      },
    },
  };

  const router = new ModelRouter(env, mockProviders);
  const list = router.listProviders();
  assert.equal(list.find((p) => p.id === PROVIDER_IDS.WORKERS_AI).available, true);
  assert.equal(list.find((p) => p.id === PROVIDER_IDS.DEEPSEEK).available, false);

  const res = await router.chat({
    messages: [{ role: "user", content: "hi" }],
    policy: { prefer: PROVIDER_IDS.DEEPSEEK, allowPaid: true },
  });
  // Falls back to workers-ai when paid unavailable
  assert.equal(res.text, "ok-glm");
});

test("router enforces paid budget when provider is paid", async () => {
  const env = { ALLOW_PAID_MODELS: "true", MAX_PAID_CALLS_PER_DAY: "1" };
  let calls = 0;
  const mockProviders = {
    [PROVIDER_IDS.WORKERS_AI]: {
      id: PROVIDER_IDS.WORKERS_AI,
      isPaid: false,
      isAvailable: () => true,
      chat: async () => ({ text: "free", model: "glm", provider: PROVIDER_IDS.WORKERS_AI }),
    },
    [PROVIDER_IDS.DEEPSEEK]: {
      id: PROVIDER_IDS.DEEPSEEK,
      isPaid: true,
      isAvailable: () => true,
      chat: async () => {
        calls++;
        return { text: "paid", model: "ds", provider: PROVIDER_IDS.DEEPSEEK };
      },
    },
    [PROVIDER_IDS.GROK]: {
      id: PROVIDER_IDS.GROK,
      isPaid: true,
      isAvailable: () => false,
      chat: async () => ({ text: "x", model: "g", provider: PROVIDER_IDS.GROK }),
    },
  };
  const router = new ModelRouter(env, mockProviders);
  const r1 = await router.chat({
    messages: [{ role: "user", content: "a" }],
    policy: { prefer: PROVIDER_IDS.DEEPSEEK, allowPaid: true },
  });
  assert.equal(r1.text, "paid");
  await assert.rejects(
    () =>
      router.chat({
        messages: [{ role: "user", content: "b" }],
        policy: { prefer: PROVIDER_IDS.DEEPSEEK, allowPaid: true },
      }),
    (err) => err.code === "BUDGET_EXCEEDED"
  );
});
