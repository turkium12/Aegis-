import test from "node:test";
import assert from "node:assert/strict";
import { analyzeTask, buildPlan } from "../src/agent/engine.js";
import { verifyReply } from "../src/agent/verify.js";
import { AegisCore } from "../src/core.js";
import { MemoryStore, InMemoryBackend } from "../src/memory/store.js";
import { ModelRouter } from "../src/models/router.js";
import { PROVIDER_IDS } from "../src/models/providers.js";
import { RateLimiter } from "../src/security/guard.js";

test("analyzeTask detects tools and chat", () => {
  assert.equal(analyzeTask("/calc 1+1").type, "tool");
  assert.equal(analyzeTask("Merhaba").type, "chat");
});

test("verifyReply flags capability claims", () => {
  const v = verifyReply("I just browsed the web and found the answer.");
  assert.ok(v.flags.includes("capability_claim"));
  assert.ok(v.text.includes("doğrulama"));
});

test("AegisCore handleChat tool path without AI", async () => {
  const memory = new MemoryStore(new InMemoryBackend());
  const mockProviders = {
    [PROVIDER_IDS.WORKERS_AI]: {
      id: PROVIDER_IDS.WORKERS_AI,
      isPaid: false,
      isAvailable: () => true,
      chat: async () => ({ text: "should-not-call", model: "x", provider: "workers-ai" }),
    },
    [PROVIDER_IDS.DEEPSEEK]: { id: PROVIDER_IDS.DEEPSEEK, isPaid: true, isAvailable: () => false, chat: async () => ({}) },
    [PROVIDER_IDS.GROK]: { id: PROVIDER_IDS.GROK, isPaid: true, isAvailable: () => false, chat: async () => ({}) },
  };
  const core = new AegisCore(
    { ALLOW_PAID_MODELS: "false" },
    {
      router: new ModelRouter({ ALLOW_PAID_MODELS: "false" }, mockProviders),
      memory,
      rateLimiter: new RateLimiter(null, { maxRequests: 100 }),
    }
  );

  const out = await core.handleChat({
    messages: [{ role: "user", content: "/calc 8*8" }],
    authToken: "test-token",
  });
  assert.match(out.reply, /64/);
  assert.equal(out.provider, "tool");
});

test("AegisCore model path uses router", async () => {
  const memory = new MemoryStore(new InMemoryBackend());
  const mockProviders = {
    [PROVIDER_IDS.WORKERS_AI]: {
      id: PROVIDER_IDS.WORKERS_AI,
      isPaid: false,
      isAvailable: () => true,
      chat: async ({ messages }) => ({
        text: "Merhaba! " + messages[messages.length - 1].content,
        model: "glm-mock",
        provider: "workers-ai",
      }),
    },
    [PROVIDER_IDS.DEEPSEEK]: { id: PROVIDER_IDS.DEEPSEEK, isPaid: true, isAvailable: () => false, chat: async () => ({}) },
    [PROVIDER_IDS.GROK]: { id: PROVIDER_IDS.GROK, isPaid: true, isAvailable: () => false, chat: async () => ({}) },
  };
  const core = new AegisCore(
    { ALLOW_PAID_MODELS: "false" },
    {
      router: new ModelRouter({ ALLOW_PAID_MODELS: "false" }, mockProviders),
      memory,
      rateLimiter: new RateLimiter(null, { maxRequests: 100 }),
    }
  );

  const out = await core.handleChat({
    messages: [{ role: "user", content: "Selam" }],
    authToken: "test-token-2",
  });
  assert.match(out.reply, /Selam/);
  assert.equal(out.provider, "workers-ai");
});
