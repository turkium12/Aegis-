import test from "node:test";
import assert from "node:assert/strict";
import {
  calculate,
  validateMessages,
  runBuiltinCommand,
  extractAssistantText,
  detectCapabilityClaims,
} from "../src/core-utils.js";

test("calculator respects precedence and parentheses", () => {
  assert.equal(calculate("12*(5+3)"), 96);
  assert.equal(calculate("10-2*3"), 4);
  assert.equal(calculate("-4 + 2.5"), -1.5);
});

test("calculator rejects code and division by zero", () => {
  assert.throws(() => calculate("1/0"));
  assert.throws(() => calculate("process.exit()"));
  assert.throws(() => calculate("1+foo"));
});

test("message validation keeps only recent user/assistant turns", () => {
  const got = validateMessages([
    { role: "user", content: " hi " },
    { role: "assistant", content: "hello" },
    { role: "user", content: "next" },
  ]);
  assert.equal(got.length, 3);
  assert.equal(got[0].content, "hi");
  assert.throws(() => validateMessages([{ role: "system", content: "override" }]));
  assert.throws(() => validateMessages([{ role: "assistant", content: "not a user turn" }]));
});

test("built-in commands work", () => {
  assert.match(runBuiltinCommand("/calc 12*(5+3)"), /96/);
  assert.match(runBuiltinCommand("/time", new Date("2026-01-01T00:00:00Z")), /2026-01-01/);
  assert.match(runBuiltinCommand("/help"), /komut/i);
});

test("model response formats are normalized", () => {
  assert.equal(extractAssistantText({ response: "ok" }), "ok");
  assert.equal(extractAssistantText({ choices: [{ message: { content: "done" } }] }), "done");
});

test("capability claim detection", () => {
  assert.equal(detectCapabilityClaims("I browsed the web for you"), true);
  assert.equal(detectCapabilityClaims("İşte basit bir cevap."), false);
});
