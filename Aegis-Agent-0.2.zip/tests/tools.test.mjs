import test from "node:test";
import assert from "node:assert/strict";
import { createToolRegistry, parseSlashCommand } from "../src/tools/registry.js";
import { MemoryStore, InMemoryBackend } from "../src/memory/store.js";

test("parse slash commands", () => {
  assert.equal(parseSlashCommand("/help").tool, "help");
  assert.equal(parseSlashCommand("/calc 2+2").args.expression, "2+2");
  assert.equal(parseSlashCommand("/memory save note hello world").tool, "memory_save");
  assert.equal(parseSlashCommand("plain text"), null);
});

test("tool registry calc and memory", async () => {
  const memory = new MemoryStore(new InMemoryBackend());
  const tools = createToolRegistry({ memory });
  const ctx = { userId: "u1" };

  const calc = await tools.run("calc", ctx, { expression: "3*7" });
  assert.equal(calc.ok, true);
  assert.match(calc.result, /21/);

  const save = await tools.run("memory_save", ctx, { key: "city", content: "Ankara" });
  assert.equal(save.ok, true);

  const get = await tools.run("memory_get", ctx, { key: "city" });
  assert.match(get.result, /Ankara/);

  const list = await tools.run("memory_list", ctx, {});
  assert.match(list.result, /city/);
});
