# Aegis Agent 0.2

Aegis is an independent, modular AI **agent** starter on Cloudflare Workers + Workers AI.

It is no longer only a chatbot: it has a central **Aegis Core**, a **ModelRouter**, a **Memory** system, a limited **Agent Engine**, a **Verification** layer, and security/cost controls.

Default model: `@cf/zai-org/glm-4.7-flash` via Workers AI (no OpenAI/Claude key required).

## What is implemented in 0.2

| Area | Status |
|------|--------|
| Aegis Core (orchestrator) | Yes |
| ModelRouter + Workers AI provider | Yes |
| DeepSeek / Grok provider adapters | Code ready; disabled until keys + `ALLOW_PAID_MODELS=true` |
| Memory (KV or in-memory) | Yes — user-scoped CRUD + search |
| Safe tools (`/help`, `/time`, `/calc`, `/memory *`) | Yes |
| Simple task analysis + plan metadata | Yes |
| Verification (capability-claim heuristics) | Yes |
| Auth token, rate limit, input scan | Yes |
| Unit tests | Yes (run offline) |

## Not implemented yet (honest)

- Autonomous multi-step tool loops with external side effects
- Live web search / independent fact verification against the internet
- Real multi-model consensus or critic loop in production path
- D1 SQL memory (KV is used; D1 can be added in 0.3)
- Streaming responses
- Per-user OAuth / multi-tenant product auth

## Commands

```
/help
/time
/calc 12*(5+3)
/memory save <key> <text>
/memory get <key>
/memory list
/memory search <query>
/memory delete <key>
```

Other messages go through Core → ModelRouter → Verification.

## Deploy

Requirements: Cloudflare account, Node.js, npm.

1. Create a KV namespace:
   ```bash
   npx wrangler kv namespace create AEGIS_MEMORY
   npx wrangler kv namespace create AEGIS_MEMORY --preview
   ```
   Put the returned IDs into `wrangler.jsonc` (`id` and `preview_id`).

2. Install and login:
   ```bash
   npm install
   npx wrangler login
   ```

3. Secrets:
   ```bash
   npx wrangler secret put AEGIS_ACCESS_TOKEN
   ```
   Optional paid providers (only if you accept cost):
   ```bash
   npx wrangler secret put DEEPSEEK_API_KEY
   npx wrangler secret put XAI_API_KEY
   ```
   Then set in `wrangler.jsonc` vars or dashboard:
   - `ALLOW_PAID_MODELS` = `"true"` (default is `"false"`)
   - `MAX_PAID_CALLS_PER_DAY` (e.g. `"10"`)

4. Deploy:
   ```bash
   npm run deploy
   ```

5. Open the `workers.dev` URL and enter the access token.

## Local development

```bash
npm test          # offline unit tests (no Cloudflare account required)
npm run dev       # wrangler dev — AI calls use real Workers AI binding and quota
```

## Architecture (0.2)

```
src/
  index.js           Worker HTTP entry
  core.js            Aegis Core orchestrator
  core-utils.js      Pure helpers (validate, calc, prompts)
  ui.js              Chat UI
  models/
    providers.js     WorkersAI, DeepSeek, Grok adapters
    router.js        Selection, fallback, budget
  memory/
    store.js         KV / in-memory store + search
  agent/
    engine.js        Task analysis + plan + tool step
    verify.js        Output verification heuristics
  tools/
    registry.js      Safe tools only
  security/
    guard.js         Auth, rate limit, input scan
```

## Cost and limits

- Cloudflare Free plan documents a daily Workers AI Neuron quota (check live docs).
- Paid model calls are **off** by default.
- Rate limit default: 30 requests / minute / user (token fingerprint).

## Safety design

- No shell, no arbitrary code execution, no unrestricted file or network tools.
- Calculator is a hand-written parser (no `eval`).
- Paid APIs refuse to run without key **and** explicit allow flag **and** budget.
- Capability-claim phrases in model output are flagged.
- Prompt-injection style phrases are detected and noted in the system context.

## License / project

Independent project. GitHub: https://github.com/turkium12/Aegis-
